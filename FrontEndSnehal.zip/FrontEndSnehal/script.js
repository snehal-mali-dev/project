// Display current date and time dynamically
function updateDateTime() {
    const dateTimeElement = document.getElementById('datetime');
    const now = new Date();
    dateTimeElement.textContent = now.toLocaleString();
}

// Update time every second
setInterval(updateDateTime, 1000);
updateDateTime();

// Form validation
document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("login-form");

    if (loginForm) {
        loginForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;
            const errorMsg = document.getElementById("error-msg");

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                errorMsg.textContent = "Invalid email format";
                return;
            }

            if (password.length < 8) {
                errorMsg.textContent = "Password must be at least 8 characters";
                return;
            }

            errorMsg.textContent = "Login successful!";
        });
    }
});
